var searchData=
[
  ['unpinpage',['unPinPage',['../classbadgerdb_1_1_buf_mgr.html#aa9bdf04c8543f59744db22efa9420c89',1,'badgerdb::BufMgr']]],
  ['updaterecord',['updateRecord',['../classbadgerdb_1_1_page.html#ae24e3f6076d6c0a18d4dd2014d540bab',1,'badgerdb::Page']]],
  ['used',['used',['../structbadgerdb_1_1_page_slot.html#a4ea5ad6e73525244bb368181f21fd018',1,'badgerdb::PageSlot']]]
];

var searchData=
[
  ['_7ebadgerdbexception',['~BadgerDbException',['../classbadgerdb_1_1_badger_db_exception.html#a683b7f1ba61c04fbe8e67aeb9b54f192',1,'badgerdb::BadgerDbException']]],
  ['_7ebufhashtbl',['~BufHashTbl',['../classbadgerdb_1_1_buf_hash_tbl.html#afc222773f09bf845230edb1702224ec6',1,'badgerdb::BufHashTbl']]],
  ['_7ebufmgr',['~BufMgr',['../classbadgerdb_1_1_buf_mgr.html#aab08001e1be18bfbd4af9113e91cf953',1,'badgerdb::BufMgr']]],
  ['_7efile',['~File',['../classbadgerdb_1_1_file.html#a97fd6e3ae8dd11be883289b69d560287',1,'badgerdb::File']]],
  ['_7einvalidpageexception',['~InvalidPageException',['../classbadgerdb_1_1_invalid_page_exception.html#a8ac9f39dac3a1d3f74d168e196724589',1,'badgerdb::InvalidPageException']]]
];

<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<title>CS 564 PHP Project: Detail Search Result</title>
</head>
<body>

Here are the detail search results for 

<?php

//connect to the database
$dbconn = pg_connect("host=postgres.cs.wisc.edu port=5432 dbname=cs564_patel");
if ($dbconn == FALSE) {
	print "Connection to database failed.<br>";
}

//get the id of the tuple to find details for (via http GET)

//construct the query

//query the database

//fetch the row in the table that was returned by the query and display the results

?>


</tbody>
</table>
<!--provide a link to the previous page-->
</body>
</html>

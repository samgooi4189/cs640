<html>
<body>
<?php
   include("header.php");
?>
<b>LOAD US POPULATION AND HOUSING DATA</b><br />
<table border=0 bgcolor='white' cellspacing=7 cellpadding=2>
<form name=input method='post' action='load.php'>
  <tr>
    <td>Path to CSV File</td>
    <td><input type='text' name='path' style='width:400px;' /></td>
  </tr>
  <tr>
    <td><input type='submit' value='Load' /></td>
  </tr>
</form>
</table>
<br />
<?php
   // load data at path given into table
   // display number of records loaded and the new total number of records
?>
</body>
</html>

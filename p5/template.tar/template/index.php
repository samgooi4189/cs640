<html>
<body>
<?php
   include("header.php");

   $db_handle = pg_connect('dbname=cs564_patel host=postgres.cs.wisc.edu sslmode=require');
   $query = "select max(popestimate2010), min(popestimate2010), max(popestimate2011), min(popestimate2011), max(huest_2010), min(huest_2010), max(huest_2011), min(huest_2011) from rashmi.pop_housing_estimate_state;";
   $result = pg_exec($db_handle, $query);
   if(!$result)
   {
      echo "error with query: ".pg_errormessage($db_handle);
      die();
   }
   if(pg_numrows($result) > 0)
   {
      $max_popest2010 = pg_result($result, 0, 0);
      $min_popest2010 = pg_result($result, 0, 1);
      $max_popest2011 = pg_result($result, 0, 2);
      $min_popest2011 = pg_result($result, 0, 3);
      $max_huest2010  = pg_result($result, 0, 4);
      $min_huest2010  = pg_result($result, 0, 5);
      $max_huest2011  = pg_result($result, 0, 6);
      $min_huest2011  = pg_result($result, 0, 7);

   }
   pg_close($db_handle)
?>
<b>SEARCH FOR NOTES</b><br /><br />
<table border=0 bgcolor='white' cellspacing=7 cellpadding=2>
<form name=input method='post' action='index.php'>
  <tr>
    <td>state name (keywords) </td>
    <td><input type='text' name='state_keywords' style='width:200px;' /></td>
  </tr>
  <tr>
    <td>region name (keywords) </td>
    <td><input type='text' name='region_keywords' style='width:200px;' /></td>
  </tr>
  <tr>
    <td>division name (keywords) </td>
    <td><input type='text' name='div_keywords' style='width:200px;' /></td>
  </tr>
  <tr>
    <td>pop estimate 2010  in range </td>
    <td><?php echo "<input type='text' name='min_popest2010' style='width:200px;' value='".$min_popest2010."' />"; ?></td>
    <td> , </td>
    <td><?php echo "<input type='text' name='max_popest2010' style='width:200px;' value='".$max_popest2010."' />"; ?></td>
  </tr>
  <tr>
    <td>pop estimate 2011 in range </td>
    <td><?php echo "<input type='text' name='min_popest2011' style='width:200px;' value='".$min_popest2011."' />"; ?></td>
    <td> , </td>
    <td><?php echo "<input type='text' name='max_popest2011' style='width:200px;' value='".$max_popest2011."' />"; ?></td>
  </tr>
  <tr>
    <td>housing estimate 2010 in range </td>
    <td><?php echo "<input type='text' name='min_huest2010' style='width:200px;' value='".$min_huest2010."' />"; ?></td>
    <td> , </td>
    <td><?php echo "<input type='text' name='max_huest2010' style='width:200px;' value='".$max_huest2010."' />"; ?></td>
  </tr>
  <tr>
    <td>housing estimate 2011 in range </td>
    <td><?php echo "<input type='text' name='min_huest2011' style='width:200px;' value='".$min_huest2011."' />"; ?></td>
    <td> , </td>
    <td><?php echo "<input type='text' name='max_huest2011' style='width:200px;' value='".$max_huest2011."' />"; ?></td>
  </tr>
  <tr>
    <td><input type='submit' value='Search' /></td>
  </tr>
</form>
</table>
<br />
<?php
   // generate search results with links to inspect.php for getting details of a state.
?>
</body>
</html>

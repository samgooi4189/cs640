
<?php
   error_reporting(E_ALL & ~E_NOTICE);
?>

<center>
<br />
<table cellspacing=8>
  <tr>
  US Population And Housing Estimate Data Editor
  </tr>
  <tr>
  <td><a href="index.php">Search</a></td>
  <td><a href="load.php">Load</a></td>
  <td><a href="delete.php">Delete</a></td>
  </tr>
</table>
</center>


var searchData=
[
  ['badbufferexception',['BadBufferException',['../classbadgerdb_1_1_bad_buffer_exception.html#a12495d77cdfa368545c8a4594f1f9127',1,'badgerdb::BadBufferException']]],
  ['badgerdbexception',['BadgerDbException',['../classbadgerdb_1_1_badger_db_exception.html#a07fd2bb076246dab5233c3ceebc4d3af',1,'badgerdb::BadgerDbException']]],
  ['badindexinfoexception',['BadIndexInfoException',['../classbadgerdb_1_1_bad_index_info_exception.html#a6150d90b9684e016f37edf4a09823c9d',1,'badgerdb::BadIndexInfoException']]],
  ['badopcodesexception',['BadOpcodesException',['../classbadgerdb_1_1_bad_opcodes_exception.html#a799a52ea783be6395a86b737bbe76897',1,'badgerdb::BadOpcodesException']]],
  ['badscanparamexception',['BadScanParamException',['../classbadgerdb_1_1_bad_scan_param_exception.html#a10875a5bd3aee59598974b485b2c9878',1,'badgerdb::BadScanParamException']]],
  ['badscanrangeexception',['BadScanrangeException',['../classbadgerdb_1_1_bad_scanrange_exception.html#aefb49810c01ceec66f76bbbc09325554',1,'badgerdb::BadScanrangeException']]],
  ['begin',['begin',['../classbadgerdb_1_1_page_file.html#a5dbca56638a43899407671729076c1ba',1,'badgerdb::PageFile::begin()'],['../classbadgerdb_1_1_page.html#aa0fdb281074cd60cb1f1d6ea6d620772',1,'badgerdb::Page::begin()']]],
  ['blobfile',['BlobFile',['../classbadgerdb_1_1_blob_file.html#a5356e5ca50d7673ea23b8c1432712f67',1,'badgerdb::BlobFile::BlobFile(const std::string &amp;name, const bool create_new)'],['../classbadgerdb_1_1_blob_file.html#a9ce275ae23b6ffeeafcaf6ac26d1b6ba',1,'badgerdb::BlobFile::BlobFile(const BlobFile &amp;other)']]],
  ['btreeindex',['BTreeIndex',['../classbadgerdb_1_1_b_tree_index.html#a4867de84c5392d9df9cb54438dd35d38',1,'badgerdb::BTreeIndex']]],
  ['bufferexceededexception',['BufferExceededException',['../classbadgerdb_1_1_buffer_exceeded_exception.html#ab15b1a0d0e13bd8a7d831f4943f744cf',1,'badgerdb::BufferExceededException']]],
  ['bufhashtbl',['BufHashTbl',['../classbadgerdb_1_1_buf_hash_tbl.html#a3928e864b3739c5772020c3eb3edec7c',1,'badgerdb::BufHashTbl']]],
  ['bufmgr',['BufMgr',['../classbadgerdb_1_1_buf_mgr.html#a18b7cf23b619c7c0e593d1dc45da77b4',1,'badgerdb::BufMgr']]],
  ['bufstats',['BufStats',['../structbadgerdb_1_1_buf_stats.html#ad9848260b3b787f15eb1b960b0f8e769',1,'badgerdb::BufStats']]]
];
